//
//  SingleAdsViewController.swift
//  AdsTutorial
//
//  Created by Gabriel Theodoropoulos on 29/07/16.
//  Copyright © 2016 Appcoda. All rights reserved.
//

import UIKit

class SingleAdsViewController: UIViewController {

    @IBOutlet weak var viewAdContainer: UIView!
    
    @IBOutlet weak var lblAdTitle: UILabel!
    
    @IBOutlet weak var lblAdBody: UILabel!
    
    @IBOutlet weak var imgAdIcon: UIImageView!
    
    @IBOutlet weak var btnAdAction: UIButton!
    
    @IBOutlet weak var lblSocialContext: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        viewAdContainer.hidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    
    @IBAction func loadNativeAd(sender: AnyObject) {
        
    }
    
}
